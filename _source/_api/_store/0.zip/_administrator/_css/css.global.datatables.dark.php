/******************************************************* dark Table Style for Datatables  *********/
.x_class_table_listing {
	color: #CCCCCC ;
	max-width: 100%;
	margin-left: 0px;
	margin-right: 0px;
}

.dataTables_length, .dataTables_filter, .dataTables_info, .dataTables_paginate  {
	color: #CCCCCC !important;
}

.dataTables_paginate  .current {
	color: #CCCCCC !important;
}