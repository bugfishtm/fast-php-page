<?php
	/* 	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  	
							www.bugfish.eu
							
	    Bugfish Fast PHP Page Framework
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		// Initialize File will be loaded if site Mode is Active
	*/
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); }
	switch(_HIVE_URL_CUR_[0]) {
		case false: case "":
			Header("Location: ./?"._HIVE_URL_GET_[0]."=startpage");
			break;
	}
	x_cookieBanner_Pre(_HIVE_SITE_COOKIE_);
	switch(_HIVE_URL_CUR_[0]) {
		case "startpage":
				hive__volt_header($object, "Home", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="start, info, homepage, info, bugfishcms"><meta property="og:type" content="website">    <meta property="og:description" content="Discover our Core CMS, learn about its features, and download the latest version."><meta property="og:title" content="Home'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta name="description" content="Discover our Core CMS, learn about its features, and download the latest version.">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/startpage.php");
		break;	
		case "download":
				hive__volt_header($object, "Download", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="download, homepage, info, bugfishcms"><meta property="og:type" content="website">    <meta property="og:description" content="This page serves as download page where you can download different core releases!"><meta property="og:title" content="Download'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta name="description" content="This page serves as download page where you can download different core releases!">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/download.php");
		break;
		case "modules":
			$structdata = '<script type="application/ld+json">{"@context": "http://schema.org","@type": "ItemList","itemListElement": [';
			$mods = $object["mysql"]->select("SELECT * FROM "._TABLE_STORE_." WHERE is_active = 1 ORDER BY mod_rname, mod_version DESC", true);
			$last = false;
			if(is_array($mods)) {
				$mods = array_reverse($mods);
				foreach($mods as $key => $value) {
					if($value["mod_rname"] == $last) { 
						continue;
					}
					$last = $value["mod_rname"];	
					$structdata .= '{"@type": "ListItem","position": '.$key.',"item": {"@type": "Product","name": "'.htmlspecialchars($value["mod_name"], ENT_QUOTES, 'UTF-8').'","description": "'.htmlspecialchars($value["mod_short"], ENT_QUOTES, 'UTF-8').'","brand": {"@type": "Brand","name": "'.htmlspecialchars($value["mod_autor"], ENT_QUOTES, 'UTF-8').'","image": "./_core/_image/module_cover.jpg"},"offers": {"@type": "Offer","price": "0.00","priceCurrency": "USD","availability": "http://schema.org/InStock"}, "image": "./_store/_module-img/'.$value["mod_rname"]."-".$value["mod_version"].'.jpg", "shippingDetails": {"@type": "ShippingDeliveryTime","shippingPolicy": "No shipping required for downloadable products"},"warranty": "No warranty provided in any way.","legalDisclaimer": "No liability for damages or data loss associated with the use of this product.","hasMerchantReturnPolicy": {"@type": "MerchantReturnPolicy","refundType": "NoRefunds","returnPolicyCategory": "Software"},"review": [],"priceValidUntil": "2077-12-31","aggregateRating": {"@type": "AggregateRating","ratingValue": "5","reviewCount": "1"}}},';
				}
				$structdata = substr($structdata, 0, -1);
			}				
			$structdata .= "]}</script>";
				hive__volt_header($object, "Store", $structdata.'<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="store, extensions, modules, bugfishcms"><meta property="og:type" content="website"><meta name="description" content="Explore and download extensions for our CMS to enhance its functionality."><meta property="og:description" content="Explore and download extensions for our CMS to enhance its functionality."><meta property="og:title" content="Store'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/store.php");
		break;		
		case "support":
				hive__volt_header($object, "Support", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="support, help, bugfishcms"><meta property="og:type" content="website"><meta property="og:description" content="Get help and support for our products and services. Contact our support team for assistance."><meta property="og:title" content="Support'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta name="description" content="Get help and support for our products and services. Contact our support team for assistance.">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/support.php");
		break;			
		case "documentation":
				hive__volt_header($object, "Documentation", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="documentation, help, bugfishcms"><meta property="og:type" content="website"><meta name="description" content="Access comprehensive guides and documentation for using our product."><meta property="og:description" content="Access comprehensive guides and documentation for using our product."><meta property="og:title" content="Documentation'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/documentation.php");
		break;			
		case "privacy":
				hive__volt_header($object, "Privacy", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="privacy, bugfishcms"><meta property="og:type" content="website"><meta name="description" content="Read our privacy policy to understand how we handle your personal data and protect your privacy."><meta property="og:title" content="Privacy'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta property="og:description" content="Read our privacy policy to understand how we handle your personal data and protect your privacy.">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/privacy.php");
		break;				
		case "license":
				hive__volt_header($object, "License", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="license, gpl, bugfishcms"><meta name="description" content="Information about the projects license!"><meta property="og:description" content="Information about the projects license!"><meta property="og:title" content="License'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta property="og:type" content="website">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/license.php");
		break;		
		case "impressum":
				hive__volt_header($object, "Imprint", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="imprint, owner, bugfishcms"><meta name="description" content="Find legal information and contact details in our Impressum."><meta property="og:description" content="Find legal information and contact details in our Imprint."><meta property="og:title" content="Imprint'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta property="og:type" content="website">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/impressum.php");
		break;	
		default:
				hive__volt_header($object, "Error 404", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="noindex, nofollow">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				echo "<br />"; hive__volt_404($object, "Error 404", "Page not found!");	
	}	
	
	$object["eventbox"]->show("Close");
	x_cookieBanner(_HIVE_SITE_COOKIE_, true);
	hive__volt_footer($object, _STORE_FOOTER_);
