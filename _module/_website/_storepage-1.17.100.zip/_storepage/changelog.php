<?php
	$x = "Disabled Scripts for User Operations, as this is not needed on this website module.";