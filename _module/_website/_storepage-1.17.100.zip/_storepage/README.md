# Public Store Module page

Store page module which is displayed on store.bugfish.eu!  
You can explore this module for investigation on how to use the cms.  
You can also copy the module and make something own out of it, or use it for your own store!