<?php
	$x = "It is not recommended to use this module. Get your insights out of the _administrator module, as this is the most enhanced module by the creators. This module is just a prototype.";