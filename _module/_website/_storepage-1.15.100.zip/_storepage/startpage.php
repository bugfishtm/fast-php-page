<?php
	/* 	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  	
							www.bugfish.eu
							
	    Bugfish Fast PHP Page Framework
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } ?>	
              <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">bugfishCMS</h1>
                    </div>
                </div>
            </div>  
            <div class="row mb-0">
                <div class="col-12 col-xl-8">	
					<div class="col-12 mb-4">
						<div class="row mb-4">
							<div class="col-12 col-sm-16 col-xl-16 mb-0">
								<div class="card border-0 shadow">
									<div class="card-body pb-0">
										<div class="row d-block d-xl-flex align-items-center">
											<h2 class="h5">Prologue: Seize Digital Power!</h2>
											<p>bugfishCMS is a powerful content management system for both end-users and developers. Manage user permissions, debug websites, and customize the admin interface with ease. Enjoy multi-language support, dynamic color schemes, and a simple GUI installer.</p>

											<p>For developers, bugfishCMS offers advanced features like multi-site management, framework integration, and dynamic code loading. Use the extension store for additional functionalities and integrated CRM tools for customer management. Boost productivity with calendar scheduling, task management, and project workflows.</p>

											<p>Whether building a blog or a corporate site, bugfishCMS provides the flexibility and developer-friendly tools to bring your vision to life. Start today and enhance your online presence with bugfishCMS!</p>

										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
					<div class="col-12 mb-4">
						<div class="row mb-4">
							<div class="col-12 col-sm-16 col-xl-16 mb-0">
								<div class="card border-0 shadow">
									<div class="card-body pb-0">
										<div class="row d-block d-xl-flex align-items-center">
											<h2 class="h5">Download</h2>
											<p>Access our CMS by visiting our download page. Additionally, explore our official Store to download modules and extensions. Remember, you can conveniently download all extensions directly within your CMS Instances store connection. Enjoy seamless access to a wide range of tools and features for enhancing your website's functionality.<br /> <a href="./?l1=download" class="btn btn-info">Download</a></p>

										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
					<div class="col-12 mb-4">
						<div class="row mb-4">
							<div class="col-12 col-sm-16 col-xl-16 mb-0">
								<div class="card border-0 shadow">
									<div class="card-body pb-0">
										<div class="row d-block d-xl-flex align-items-center">
											<h2 class="h5">Store</h2>
											<p>Discover a variety of site modules available in our store for your bugfishCMS instance. Enhance your website's functionality with features like e-commerce, blogging, galleries, event calendars, contact forms, SEO optimization, analytics, social media integration, membership management, and customizable design options. Additionally, leverage the _administrator module for effortless store hosting directly from your default CMS installation. Elevate your website's professionalism and capabilities with our comprehensive selection of modules.<br /><a href="./?l1=modules" class="btn btn-info">Store</a></p>

										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
                </div>
				<?php
				$features1 = [
					"User and Group Manager" => "Organize users into distinct groups for streamlined access control and collaboration. Link different features and functions to groups, giving you great control over your user base. Essential for managing user permissions and access levels, ensuring that only authorized users can access sensitive information.",
					"Debug Insights" => "Maintain full control over multi-site debugging operations to ensure that your deployed websites and modules function perfectly. Crucial for developers and administrators to troubleshoot and optimize the performance of the CMS.",
					"Dynamic Colors" => "Customize the appearance of the Administrator Module with various color schemes. Enhances user experience by allowing customization of the CMS interface to match branding or personal preference.",
					"Multi-Language Support" => "Currently supports English, Japanese, German, and Spanish languages. Facilitates a broader reach by supporting multiple languages, enhancing usability for non-English speakers.",
					"Installer" => "Simplified installation process with a graphical user interface (GUI). Reduces the technical barrier for end-users.",
					"Updater" => "Easy-to-use updater with a graphical user interface (GUI) for seamless updates. Simplifies the maintenance of the CMS.",
					"Extension and Dedicated Store" => "Centralized marketplace for discovering, installing, and managing extensions, including setting up a dedicated extension store for customization and monetization. Empowers users to enhance their CMS with additional functionalities tailored to their needs.",
					"File Management" => "Robust file management capabilities for uploading, organizing, and managing files and media assets. Ensures efficient organization and retrieval of media and document files, crucial for content-heavy websites.",
					"CRM Functionalities" => "Integrated customer relationship management functionalities within the CMS. Helps users manage customer relationships directly within the CMS.",
					"Calendar" => "Built-in calendar feature for scheduling events, appointments, and reminders. Streamlines scheduling and improves productivity.",
					"Task Management" => "Capabilities for creating, assigning, and tracking tasks and workflows. Improves overall productivity by managing tasks efficiently.",
					"Administration Interface" => "Comprehensive, responsive administration backend featuring file management, user management, debugging insights, and access to the extension store. Centralizes all administrative functions, providing a user-friendly and powerful control panel.",
					"Store System and Module Downloads" => "Fully functional store system for accessing and downloading site modules, enhancing website customization.",
					"Notes" => "Allows users to create and manage personal notes.",
					"Notification System" => "System notifications to inform users about events and changes.",
					"Administrator Dashboard" => "Provides an overview and centralized control in an administrator dashboard.",
					"Project Management" => "Tools for managing projects and project workflows.",
					"Customer Manager" => "CRM manager for handling customers and related projects, tasks, and activities.",
					"Ticket System" => "Ticketing system to track and resolve customer issues efficiently.",
					"Docker Control" => "Integrated control of Docker containers within the CMS. Provides advanced users with tools to manage containerized applications, enhancing scalability and deployment flexibility.",
					"Forum Discussions" => "Enables forum discussions among users. Promotes community engagement.",
					"Knowledge Base" => "Create and share a knowledge base with users or the public. Enhances knowledge sharing and support.",
					"Inventory Manager" => "Manage articles and inventory items efficiently.",
					"Newsletter Manager" => "Tools for creating and managing newsletters.",
					"Comments" => "Manage comments across different site areas.",
					"MySQL Manager" => "Integrated SQL tools for managing connected databases."
				];
				$features2 = [
					"Multi-Site Management" => "Effortlessly manage multiple websites from a centralized platform, ensuring efficient oversight of various online properties.",
					"Framework Integration" => "Seamlessly integrate with the Bugfish Framework for comprehensive bug tracking and debugging capabilities, including all classes and functionalities of CSS, JavaScript, and PHP Libraries.",
					"Debugging Tools" => "Access robust debugging tools to enhance backend operations, quickly identify errors, and test site performance or SQL issues with various classes.",
					"Multi-Language Support" => "Dynamically add and manage multiple languages to cater to a global audience.",
					"Dynamic Themes and Colors" => "Enable dynamic switching of website themes and adjustment of theme colors for a personalized appearance.",
					"Dynamic CSS/JS Load" => "Facilitate the dynamic loading of CSS and JavaScript files for optimized website performance.",
					"Installer Backend" => "Utilize ready-to-use installer routines per Site Module for seamless project setup.",
					"Updater Backend" => "Leverage ready-to-use updater routines per Site Module for effortless project updates.",
					"Dynamic Code Loading" => "Support the dynamic loading of code snippets or scripts for advanced customization options.",
					"Dynamic Cronjobs" => "Schedule and execute dynamic cronjobs within the CMS to automate routine tasks.",
					"Advanced User Operations" => "Access pre-written user operations such as email activation and password recovery for enhanced user management.",
					"Extension Support" => "Extend different modules with custom or store-downloaded extensions.",
					"CMS Folder Structure" => "Utilize an easy-to-use folder structure that accommodates all necessary data, allowing for straightforward backups and restoration.",
					"Deployment" => "Deploy your own cluster of bugfishCMS instances and control module and core update deployments via your own instances public store.",
					"Integrated Templates" => "Access a selection of pre-designed templates integrated into the CMS for simplified website design and customization.",
					"Example Modules" => "Explore a collection of example modules showcasing various functionalities and capabilities of the CMS, serving as references and inspiration for users and developers.",
					"Developer-Friendly Interface" => "Utilize a comprehensive user interface tailored for developers to access and manipulate the system through coding, enabling extensive customization and advanced functionality.",
					"Page and Procedure Building" => "Design web pages and create complex workflows using pre-designed, extendable widgets for visually appealing and user-friendly pages.",
					"Database Change Updater" => "Dynamically update the database to align with the current build version, ensuring smooth transitions and robust database management.",
					"Control Scripts" => "Employ various scripts to control the software during development, simplifying the developer's workflow."
				];
				?>
                <div class="col-12 col-xl-4 mb-4">
					<div class="card border-0 shadow">
						<div class="card-header">
							<div class="row align-items-center">
								<div class="col">
									<h2 class="fs-5 fw-bold mb-0">Features</h2>
									<small>Overview of different CMS and Backend related Features.</small>
								</div>
							</div>
						</div>			
						<div class="table-responsive" style="max-height: 600px;">
							<table class="table align-items-center table-flush" style="max-width: 100%;">
								<tbody>
								<tr>
									<td class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;">
										<b>End-User Functionalities</b>
									</td>
								</tr>
								<?php foreach($features1 as $key => $value) {  ?>
								<tr>
									<td class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;">
								✅ <?php echo $key; ?> <br />
								<small><?php echo $value; ?></small>
									</td>
								</tr>
								<?php } 
								?>
								<tr>
									<td class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;">
										<b>Developer Functionalities</b>
									</td>
								</tr>
								<?php foreach($features2 as $key => $value) {  ?>
								<tr>
									<td class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;">
								✅ <?php echo $key; ?> <br />
								<small><?php echo $value; ?></small>
									</td>
								</tr>
								<?php } 
								?>
								</tbody>
							</table>
						</div>
					</div>
                </div>
            </div>

			<?php
				$libraries = [
					[
						"Folder Name" => "alpine",
						"License" => "MIT",
						"Github Link" => "https://github.com/alpinejs/alpine"
					],
					[
						"Folder Name" => "boxicons",
						"License" => "MIT",
						"Github Link" => "https://github.com/atisawd/boxicons"
					],
					[
						"Folder Name" => "sortablejs",
						"License" => "MIT",
						"Github Link" => "https://github.com/SortableJS/Sortable"
					],
					[
						"Folder Name" => "choices.js",
						"License" => "MIT",
						"Github Link" => "https://github.com/Choices-js/Choices"
					],
					[
						"Folder Name" => "multi.js",
						"License" => "MIT",
						"Github Link" => "https://github.com/fabianlindfors/multi.js/"
					],
					[
						"Folder Name" => "select2",
						"License" => "MIT",
						"Github Link" => "https://github.com/select2/select2"
					],
					[
						"Folder Name" => "tinymce",
						"License" => "MIT",
						"Github Link" => "https://github.com/tinymce/tinymce"
					],
					[
						"Folder Name" => "sweetalert2",
						"License" => "MIT",
						"Github Link" => "https://github.com/sweetalert2/sweetalert2"
					],
					[
						"Folder Name" => "space_invader",
						"License" => "MIT",
						"Github Link" => "https://github.com/ozelentok/SpaceInvaders"
					],
					[
						"Folder Name" => "resumable",
						"License" => "MIT",
						"Github Link" => "https://github.com/23/resumable.js"
					],
					[
						"Folder Name" => "modelviewer",
						"License" => "Apache",
						"Github Link" => "https://github.com/google/model-viewer"
					],
					[
						"Folder Name" => "leafletjs",
						"License" => "BSD2",
						"Github Link" => "https://github.com/Leaflet/Leaflet"
					],
					[
						"Folder Name" => "jquery",
						"License" => "MIT",
						"Github Link" => "https://github.com/jquery/jquery"
					],
					[
						"Folder Name" => "bugfish-jquery-sortselect",
						"License" => "GPLv3",
						"Github Link" => "https://github.com/bugfishtm/bugfish-jquery-sortselect"
					],
					[
						"Folder Name" => "datatables",
						"License" => "MIT",
						"Github Link" => "https://github.com/DataTables/DataTables"
					],
					[
						"Folder Name" => "magicsuggest",
						"License" => "MIT",
						"Github Link" => "https://github.com/Magicsuggest/magicsuggest"
					],
					[
						"Folder Name" => "free-file-icons",
						"License" => "MIT",
						"Github Link" => "https://github.com/redbooth/free-file-icons"
					],
					[
						"Folder Name" => "focustrap",
						"License" => "MIT",
						"Github Link" => "https://github.com/focus-trap/focus-trap"
					],
					[
						"Folder Name" => "chartjs",
						"License" => "MIT",
						"Github Link" => "https://github.com/chartjs"
					],
					[
						"Folder Name" => "boxicons (Image List)",
						"License" => "MIT",
						"Github Link" => "https://github.com/atisawd/boxicons",
						"Additional Link" => "https://boxicons.com"
					],
					[
						"Folder Name" => "bugfish-dashboard",
						"License" => "GPLv3",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "country-flags-icons",
						"License" => "MIT",
						"Github Link" => "https://github.com/ashhitch/ISO-country-flags-icons"
					],
					[
						"Folder Name" => "animate-css",
						"License" => "HYP",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "autosize",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "animate",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "bootstrap",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "bootstrap-colorpicker",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "bootstrap-material-datetimepicker",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "bootstrap-notify",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "bootstrap-select",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "bootstrap-tagsinput",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "chosen",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "dropzone",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "editable-table",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "flot-charts",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "gmaps",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "ion-rangeslider",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jquery-cookie",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jquery-countto",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jquery-inputmask",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jquery-knob",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jquery-slimscroll",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jquery-sparkline",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jquery-spinner",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jquery-steps",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jquery-validation",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "jvectormap",
						"License" => "AGPL",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "light-gallery",
						"License" => "GPLv3",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "material-design-iconic-font",
						"License" => "Apache",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "materialize-css",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "momentjs",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "morrisjs",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "multi-select",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "nestable",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "node-waves",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "nouislider",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "raphael",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "waitme",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "Windmill Theme",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "Responsive Mail Template",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "Responsive Error Page",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "You-Login Resposive Template",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "Volt Administrator Dashboard Lite",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "Notyf",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "Smooth-Scroll",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "onscreen",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "waypoints",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "sass",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "chatist",
						"License" => "MIT",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "githubbuttons",
						"License" => "BSD",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "animated-calender",
						"License" => "BSD",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "login-template",
						"License" => "BSD",
						"Github Link" => "None"
					],
					[
						"Folder Name" => "Google Fonts",
						"License" => "OTF/Apache2",
						"Github Link" => "None"
					]
				];
			?>	
            <div class="row mb-0">
                <div class="col-12 col-xl-4 mb-4">
					<div class="card border-0 shadow">
						<div class="card-header">
							<div class="row align-items-center">
								<div class="col">
									<h2 class="fs-5 fw-bold mb-0">Included Libraries</h2>
									<small>This table lists third-party scripts integrated into the CMS.</small>
								</div>
							</div>
						</div>			
						<div class="table-responsive" style="max-height: 600px;">
							<table class="table align-items-center table-flush" style="max-width: 100%;">
								<tbody>
								<?php foreach($libraries as $key => $value) {  ?>
								<tr>
									<td class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;">
								📜 <?php echo $value["Folder Name"]; ?> <small><?php if($value["Github Link"] != "None") { ?> [<a href="<?php echo $value["Github Link"]; ?>" target="_blank" rel="noopener" class="text-info">Github</a>] <?php } ?> [License:<?php echo $value["License"]; ?>]</small>
									</td>
								</tr>
								<?php } 
								?>
								</tbody>
							</table>
						</div>
					</div>
                </div>
                <div class="col-12 col-xl-8">	
					<div class="col-12 mb-4">
						<div class="row mb-4">
							<div class="col-12 col-sm-16 col-xl-16 mb-4">
								<div class="card border-0 shadow">
									<div class="card-body pb-0">
										<div class="row d-block d-xl-flex align-items-center">
											<h2 class="h5">Tutorials</h2>
											<p>We have a Youtube Playlist dedicated to Tutorials about "bugfishCMS". Take a look at our channel if you want to know more!<br /> <a href="https://www.youtube.com/playlist?list=PL6npOHuBGrpAfrpUzQPTOWdqoCnhq1oP0" rel="noopener" target="_blank" class="btn btn-info">Visit Youtube Playlist</a></p>
											
										</div>
									</div>
								</div>
							</div>
							<div class="col-12 col-sm-16 col-xl-16 mb-0">
								<div class="card border-0 shadow">
									<div class="card-body pb-0">
										<div class="row d-block d-xl-flex align-items-center">
											<h2 class="h5">Screenshots</h2>
											<div data-gallery="simple" data-loop="true" data-interval="5">
												<figure id="image-1">
													<img src="./_site/<?php echo _HIVE_MODE_; ?>/_theme/adminbsb.png" style="border-radius: 5px;">
												</figure>
												<figure id="image-2">
													<img src="./_site/<?php echo _HIVE_MODE_; ?>/_theme/windmill.png" style="border-radius: 5px;">
												</figure>
												<figure id="image-3">
													<img src="./_site/<?php echo _HIVE_MODE_; ?>/_theme/volt.png" style="border-radius: 5px;">
												</figure>
												<figure id="image-4">
													<img src="./_site/<?php echo _HIVE_MODE_; ?>/_theme/minimal.png" style="border-radius: 5px;">
												</figure>
												<nav>
													<small>
														[<a href="#image-1" class="text-info">AdminBSB Example</a>] 
														[<a href="#image-2" class="text-info">[Windmill Example]</a>] 
														[<a href="#image-3" class="text-info">[Volt Example]</a>] 
														[<a href="#image-4" class="text-info">[Minimal Example]</a>]
													</small>
												</nav>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
                </div>
            </div>
			<script>
							/*!
				 * jQuery Simple Gallery Plugin v2.1
				 * https://github.com/straube/simple-gallery
				 *
				 * Copyright 2013, 2014 Gustavo Straube
				 */
				;(function ($) {

					'use strict';

					$.fn.gallery = function (options) {

						return this.each(function () {
							var settings = $.extend({}, $.fn.gallery.defaults, options);
							var $gallery = $(this);
							var $images  = $gallery.find(settings.tag);
							var loop;

							// Local functions
							var show = function ($image) {
								$images.removeClass('current').fadeOut().promise().done(function () {
									$image.addClass('current').fadeIn();
								});
							};

							$images.hide().first().show().addClass('current');

							$gallery.find('a').on('click', function (event) {
								var id = this.href.replace(/^[^#]*(#.*)?$/i, '$1');
								if (!id) {
									return true;
								}
								event.preventDefault();
								window.clearInterval(loop);
								loop = null;
								show($images.filter(id));
							});

							if (settings.loop) {
								var interval = settings.interval * 1000;
								loop = window.setInterval(function () {
									var $next = $images.filter('.current').next(settings.tag);
									if ($next.length === 0) {
										$next = $images.first();
									}
									show($next);
								}, interval);
							}
						});

					};

					$.fn.gallery.defaults = {
						tag      : 'figure',
						loop     : true,
						interval : 5
					};

					$(function () {
						var $simple = $('[data-gallery="simple"]');
						if ($simple.length) {
							$simple.gallery($simple.data());
						}
					});

				})(jQuery); 
			</script>