<?php
	$x = "Newest version with actual features and more!";