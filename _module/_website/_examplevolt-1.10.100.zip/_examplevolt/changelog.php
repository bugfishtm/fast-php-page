<?php
	$x = "Initial Release - No known Bugs and no Features planned.";