<?php
	/* 	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  	
							www.bugfish.eu
							
	    Bugfish Fast PHP Page Framework
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } ?>	
              <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">bugfishCMS</h1>
                    </div>
                </div>
            </div>               

            <div class="row mb-4">
                <div class="col-12 col-sm-16 col-xl-16 mb-0">
                    <div class="card border-0 shadow">
                        <div class="card-body pb-0">
                            <div class="row d-block d-xl-flex align-items-center">
                                <h2 class="h5">bugfishCMS: Seize Digital Power!</h2>
								<p>bugfishCMS is an actively evolving, GPLv3-licensed Content Management System (CMS) seamlessly integrating with Bugfish Framework and Admin Module. It offers advanced backend capabilities for website module development. Users currently viewing the CMS Download and Store page can access the CMS and acquire new modules, which are also available within the administrator module inside the CMS. Comprehensive documentation facilitates expedited multi-site deployment and development for complex projects.</p>
                            </div>
                            <div class="row d-block d-xl-flex align-items-center">
                                <h2 class="h5">Functionalities</h2>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Multi Site Hosting</h3>The Multi Site Hosting feature in bugfishCMS allows administrators to host and manage multiple websites from a single installation of the CMS. This capability streamlines the process of overseeing various domains, subdomains, or separate sites by centralizing their administration. It is particularly useful for organizations with multiple brands or regional sites, providing a unified dashboard to handle content, themes, plugins, and user management across all sites. This feature also supports shared resources among sites, optimizing performance and reducing redundancy.')">Multi Site Hosting</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Bugfish Framework</h3>Bugfish Framework is the underlying foundation of bugfishCMS, designed to offer developers a robust, scalable, and flexible environment for creating custom web applications. This framework includes a rich set of libraries, APIs, and tools that facilitate rapid development and integration. It supports modular architecture, ensuring that components can be easily added, removed, or modified without affecting the core system. The framework is optimized for performance and security, providing a solid base for building secure, high-performance web solutions.')">Bugfish Framework</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Site Builder</h3>The Site Builder feature provides a comprehensive set of tools for creating and designing web pages without needing extensive coding knowledge. Users can leverage drag-and-drop functionality, pre-built templates, and a wide range of customizable elements to construct visually appealing and functional web pages. The Site Builder includes WYSIWYG (What You See Is What You Get) editors, allowing users to see real-time changes as they design. It also supports responsive design, ensuring that websites look great on all devices.')">Site Builder</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>User Manager</h3>User Manager in bugfishCMS is a robust tool for handling all aspects of user account management. Administrators can create, edit, and delete user accounts, assign roles, and set specific permissions for different users. This feature supports user registration, password recovery, and profile management, providing a secure and user-friendly experience. Additionally, User Manager includes tools for monitoring user activity, enforcing security policies, and managing authentication settings.')">User Manager</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>DNS Manager</h3>The DNS Manager feature in bugfishCMS provides tools for managing Domain Name System (DNS) settings directly within the CMS. This includes configuring domain records such as A, CNAME, MX, TXT, and more, allowing administrators to easily manage the routing of their domain traffic. The DNS Manager ensures seamless updates and changes to DNS settings, providing real-time propagation and monitoring tools. This feature also supports DNS replication, ensuring redundancy and high availability by automatically synchronizing DNS records across multiple servers. This is essential for maintaining website accessibility, optimizing performance, and ensuring proper domain management.')">DNS Manager</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Group Manager</h3>The Group Manager feature allows administrators to organize users into groups to streamline permission management and access control. By categorizing users based on roles, departments, or other criteria, administrators can assign permissions at the group level, making it easier to manage large numbers of users. This feature supports hierarchical group structures, enabling more granular control over access rights and responsibilities. Group Manager enhances security and efficiency by ensuring that users have appropriate access to resources and features.')">Group Manager</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Permission Manager</h3>Permission Manager provides detailed control over what users and groups can see and do within the CMS. Administrators can define permissions for various actions such as creating, editing, deleting, and viewing content. This feature supports group-based access control (GBAC), allowing for the creation of custom roles with specific permission sets. Permission Manager ensures that sensitive information is protected and that users have access only to the features and data necessary for their roles.')">Permission Manager</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>File Manager</h3>File Manager is an essential feature for managing all files and media assets used within the CMS. It provides a user-friendly interface for uploading, organizing, and managing files such as images, videos, documents, and more. Users can create directories, move files, rename items, and set permissions for different file types. ')">File Manager</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>MySQL Manager</h3>MySQL Manager offers comprehensive tools for managing MySQL databases directly from the CMS. Administrators can create, edit, and delete databases, run queries, and perform backups and restores. This feature includes an intuitive interface for managing database tables and fields, making it easier to handle complex database tasks. MySQL Manager ensures that database management is streamlined and accessible, even for users with limited SQL knowledge.')">MySQL Manager</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>CRM</h3>The Customer Relationship Management (CRM) feature integrates tools for managing customer interactions and data. This functionality is connectable with the integrated Docker Hosting functionality.')">CRM</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Messaging</h3>Messaging within BugfishCMS enables internal communication among users. This feature includes functionalities for sending and receiving messages, creating group chats, and organizing conversations into threads. Messaging supports real-time notifications and integrates with other CMS features, such as User Manager and CRM, to facilitate seamless communication. It enhances collaboration by providing a centralized platform for discussions, announcements, and information sharing.')">Messaging</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Calendar</h3>The Calendar feature provides tools for scheduling and managing events, appointments, and deadlines. Users can create events, set reminders, and share calendars with others. The Calendar supports recurring events, multiple calendar views (daily, weekly, monthly), and integration with other CMS features like CRM and Messaging. This feature helps keep teams organized and ensures that important dates and deadlines are tracked and managed efficiently.')">Calendar</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Docker Hosting</h3>Docker Hosting in BugfishCMS allows applications to be hosted within Docker containers, ensuring consistent environments across development, testing, and production. This feature simplifies deployment by packaging applications and their dependencies into isolated containers. Docker Hosting supports scalability, version control, and easy rollbacks, making it ideal for maintaining high availability and reliability in web hosting environments.')">Docker Hosting</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Store</h3>The Store feature in bugfishCMS provides a marketplace where users can browse, download, and deploy various modules and plugins. This allows for easy expansion of the CMS’s functionality with additional features and tools. Users can find modules for enhancing website performance, adding new content types, integrating third-party services, and more. The Store simplifies the process of customizing and extending the capabilities of bugfishCMS to meet specific needs.')">Store</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Deployment</h3>Deployment tools in bugfishCMS streamline the process of releasing updates and new features to websites. This feature includes functionalities to host an own store which will serve as a update and store server for your own instances. Deployment tools ensure that changes are deployed smoothly and efficiently, minimizing downtime and reducing the risk of errors.')">Deployment</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Forum</h3>The Forum feature provides a platform for creating and managing online discussion boards. Users can create topics, post messages, and reply to threads, fostering community engagement and knowledge sharing. The Forum supports moderation tools, user rankings, and customizable layouts. This feature is ideal for building online communities, providing customer support, and facilitating discussions on various topics.')">Forum</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Wiki</h3>The Wiki feature allows users to create and manage collaborative documentation and knowledge bases. It includes tools for editing, version control, and organizing content into categories and hierarchies. Users can easily link pages, add multimedia, and track changes over time. The Wiki feature is useful for creating comprehensive documentation, internal knowledge sharing, and collaborative content creation.')">Wiki</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Inventory</h3>The Inventory feature in bugfishCMS allows users to manage and control items such as articles, books, and other resources across multiple sites. This functionality provides tools for tracking the availability, categorization, and distribution of these items, ensuring they are easily accessible and well-organized. Users can efficiently manage inventory levels, update item details, and monitor the usage of resources across various sites, making it ideal for organizations with extensive content libraries or multi-site operations.')">Inventory</span>
								<span class="alert alert-primary hoverbtn_store" style="cursor: pointer; font-size: 14px; padding: 5px; text-align: center; float:left; max-width: 100%; width: 200px; margin-bottom: 10px; margin-right: 10px;" onclick="xjs_popup('<h3>Debugging</h3>The Debugging feature includes tools and features for identifying, diagnosing, and resolving issues within the CMS and hosted websites. It provides error logging, performance monitoring, and debugging consoles. Administrators can track and analyze errors, set breakpoints, and inspect code execution in real-time. Debugging tools help maintain the stability and performance of websites by ensuring that issues are promptly identified and addressed.')">Debugging</span>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

			<?php
				// Folder containing the files
				$folder = $object["path"].'/_store/_core/';

				// Get all files in the folder
				$files = glob($folder . '*.zip');

				// Array to store version numbers
				$versions = [];

				// Function to extract version number from filename
				function extractVersion($filename) {
					preg_match('/(\d+\.\d+)/', $filename, $matches);
					return $matches[1];
				}


				// Extract version numbers from filenames
				foreach ($files as $file) {
					//$version = extractVersion(basename($file));
					$version = basename($file);
					$versions[] = $version;
				}

				// Sort the version numbers in descending order
				$versions = array_reverse($versions);
			?>	
            <div class="row mb-0">
                <div class="col-12 col-xl-4 mb-4">
					<div class="card border-0 shadow">
						<div class="card-body ">
							<h2 class="fs-5 fw-bold mb-1">Download CMS</h2>
						 <?php if(count($versions) > 0) { ?>   <p>Here you can download the latest version of the CMS. Explore our ever-expanding "<b><a href="./?l1=modules">Extensions</a></b>"! For more information, select a module from the list below or to the right (depending on your screen size). If you have any issues, feel free to contact us using the "<b><a href="./?l1=support">How to get help</a></b>" Section. Developer and user documentation can be found in our "<b> <a href="./?l1=documentation">Documentation</a></b>" section! <br /><a href="./_store/_core/<?php echo $versions[0]; ?>" class="btn btn-primary">Download <?php echo $versions[0]; ?></a></p> <?php } else { ?><p>There is currently no release available to download!</p>  <?php }  ?>
							<div class="d-block">
								<div class="d-flex align-items-center me-5">
									<div class="icon-shape icon-sm bg-success rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M280-280h400v-80H280v80Zm200-120 160-160-56-56-64 62v-166h-80v166l-64-62-56 56 160 160Zm0 320q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Latest Release</label><br />
										<span class="h4 mb-0"><?php if(count($versions) > 0) { echo substr(@$versions[0] ?? '', 0, -4); } else { echo "Not available"; } ?></span>
									</div>
								</div>
								<div class="d-flex align-items-center pt-3">
									<div class="icon-shape icon-sm bg-info rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M120-560v-240h80v94q51-64 124.5-99T480-840q150 0 255 105t105 255h-80q0-117-81.5-198.5T480-760q-69 0-129 32t-101 88h110v80H120Zm2 120h82q12 93 76.5 157.5T435-204l48 84q-138 0-242-91.5T122-440Zm412 70-94-94v-216h80v184l56 56-42 70ZM719 0l-12-60q-12-5-22.5-10.5T663-84l-58 18-40-68 46-40q-2-13-2-26t2-26l-46-40 40-68 58 18q11-8 21.5-13.5T707-340l12-60h80l12 60q12 5 23 11.5t21 14.5l58-20 40 70-46 40q2 13 2 25t-2 25l46 40-40 68-58-18q-11 8-21.5 13.5T811-60L799 0h-80Zm40-120q33 0 56.5-23.5T839-200q0-33-23.5-56.5T759-280q-33 0-56.5 23.5T679-200q0 33 23.5 56.5T759-120Z"/></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Latest Changelog</label>
										<p style="font-size: 12px;"><?php if(file_exists($object["path"]."/_store/_core-cl/".substr(@$versions[0] ?? '', 0, -4).".html")) { require_once($object["path"]."/_store/_core-cl/".substr(@$versions[0] ?? '', 0, -4).".html"); } else { echo "Not available"; } ?></p>
									</div>
								</div>
								<div class="d-flex align-items-center pt-3">
									<div class="icon-shape icon-sm bg-warning rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="m612-292 56-56-148-148v-184h-80v216l172 172ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 320q133 0 226.5-93.5T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160Z"/></svg></div>
									<div class="d-block">
										<label class="mb-0">Project Uptime</label><br />
										<span class=" h4 mb-0" id="countup">Please Wait...</span>
									</div>
								</div>
								<p class="mt-3 mb-1">We will very appreciate support for this project on "<b><a href="https://www.patreon.com/Bugfish" rel="noopener" target="_blank">Patreon</a></b>"!</p>
							</div>
						</div>
					</div>
                </div>
				<script>
					// Specify the target date
					const targetDate = new Date('2012-12-21T00:00:00');

					// Function to update the countdown
					function updateCountup() {
						const currentDate = new Date();
						const timeDifference = currentDate - targetDate;

						// Calculate elapsed time
						const milliseconds = Math.abs(timeDifference);
						const seconds = Math.floor(milliseconds / 1000) % 60;
						const minutes = Math.floor(milliseconds / (1000 * 60)) % 60;
						const hours = Math.floor(milliseconds / (1000 * 60 * 60)) % 24;
						const days = Math.floor(milliseconds / (1000 * 60 * 60 * 24));

						// Display the elapsed time
						const countdownElement = document.getElementById('countup');
						countdownElement.innerHTML = `${days} days`;
					}

					// Update the countdown every second
					setInterval(updateCountup, 1000);

					// Initial call to update countdown
					updateCountup();
				</script>		
                <div class="col-12 col-xl-8">	
					<div class="col-12 mb-4">
						<div class="card border-0 shadow">
							<div class="card-header">
								<div class="row align-items-center">
									<div class="col">
										<h2 class="fs-5 fw-bold mb-0">bugfishCMS Releases</h2>
										<small>Here you can see and access different bugfishCMS releases. The first 3 digits represent the core release number (x.xx.), the digits after the _ sign represent the integrated administrator module release version. If the administrator release version is 0.00.000, than there is no administrator module included in the release file.</small>
									</div>
								</div>
							</div>			
							<div class="table-responsive">
								<table class="table align-items-center table-flush" style="max-width: 100%;">
									<thead class="thead-light">
									<tr>
										<th class="border-bottom" scope="col">Version</th>
										<th class="border-bottom" scope="col">Download</th>
									</tr>
									</thead>
									<tbody>
									<?php $run = false; foreach($versions as $key => $value) { $run = true; ?>
									<tr>
										<th class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;">
											<b><?php echo $value; ?></b>
											<p style="font-size: 12px; padding-bottom: 5px;margin-bottom: 0px;"><?php if(file_exists($object["path"]."/_store/_core-cl/".substr($value, 0, -4).".html")) { require($object["path"]."/_store/_core-cl/".substr($value, 0, -4).".html"); } else { echo "Not available"; } ?></p>
										</th>
										<td class="fw-bolder text-gray-500">
										   <a href="./_store/_core/<?php echo $value; ?>" class="btn btn-primary">Download</a>
										</td>
									</tr>
									<?php } 
									if(!$run) { 
										?>
											<tr>
												<td class="text-gray-900" scope="row" colspan="2">
													There is currently no core version available!
												</td>
											</tr>											
										
										<?php
									}
									?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
            </div>