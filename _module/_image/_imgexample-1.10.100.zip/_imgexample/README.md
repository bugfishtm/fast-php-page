**📦 Example Image Module**

**General Information**  

Deploy full website projects (like WordPress) using image modules in bugfishCMS. These modules don't auto-load features like MySQL table setups.

### 📁 Important Files
- `preview.jpg`: Preview image for the Administrator Module and Store.
- `changelog.php`: Document the module's changelog.
- `version.php`: Contains versioning information.

Place website content in the `htdocs` folder inside your image module.

### 🆔 Deployment Identifier File
An identifier file is created if you use the Administrator Module to deploy the image module (recommended).

### 🏷️ Naming Conventions
- Max 50 characters for module name (`RNAME`).
- Start name with "img" (e.g., `imgwordpress`).

### 🔢 Versioning
Include versioning information in the `version.php` file.

### 🚫 Limitations
Image modules:
- Cannot alter/extend existing site modules or extensions.
- Serve to deploy projects like WordPress independently.
- No control features in the Administrator Module.

Happy coding!    
Bugfish