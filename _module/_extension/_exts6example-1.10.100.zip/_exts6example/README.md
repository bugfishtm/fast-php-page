**🧩 Extension Module Example**

**General Information**

Extension modules in bugfishCMS extend the functionality of existing site modules without altering their core code. These modules are specific to a particular site module and can modify navigation, permissions, and more.

### 🏷️ Naming Conventions
- Maximum 10 characters for module name (`RNAME`).
- Must start with "ext" (e.g., `extblog`).

### 🔄 Functionality
- Extension modules are installed once per valid site module they extend.
- They are associated with pre-defined variables detailed in example files' comments.

## 📂 Folder Structure

Organize your extension module ZIP file as follows. Replace `RNAME` with your module name.

```
./RNAME/
├── _admin/
│   ├── mod_setting.php (Administrator page settings)
│   └── mod_index.php (Administration module load.php)
├── _config/
│   ├── config_post.php (Post-configuration addition)
│   └── config_pre.php (Pre-configuration addition)
├── _cron/
│   └── * (Additions for related site module's cronjobs)
├── _css/
│   └── css.*.php (Additions for related site module's stylesheet.php autoload file)
├── _js/
│   └── js.*.php (Additions for related site module's javascript.php autoload file)
├── _mysql/
│   └── mysql.*.php (Additions for related site module's MySQL Tables)
├── _lib/
│   └── lib.*.php (Additions for related site module's Library Functionalities)
├── _wfc/
│   └── wfc.*.php (Additions for related site module's WFC Functionalities)
├── version.php (Versioning info)
├── changelog.php (Changelog)
└── preview.jpg (Preview image)
```

Happy Coding!  
Bugfish <3