# Example Extension Module

**This is an Example Extension Module for the _administrator Interface Module!**

You can explore this module for investigation on how to use the cms.  
You can also copy the module and make something own out of it, or use it for your own store!  You can use this as skeleton or to see how extension modules work.