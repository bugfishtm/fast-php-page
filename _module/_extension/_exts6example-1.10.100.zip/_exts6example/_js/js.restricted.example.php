<?php
	/* 
		 _               __ _    _    ___ __  __ ___ 
		| |__ _  _ __ _ / _(_)__| |_ / __|  \/  / __|
		| '_ \ || / _` |  _| (_-< ' \ (__| |\/| \__ \
		|_.__/\_,_\__, |_| |_/__/_||_\___|_|  |_|___/
				  |___/                              

		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			Inject Javascript Code in javascript.php for site module for Logged In Users.
			
		You will have access to all site variables and object array functionalities.
		Available Varilables dedicated to this extension:						
		 $object[extension][name] = Current rname of Extension (Extensions are always only single-installable so the fodler name is rname)
		 $object[extension][prefix] =  Prefix for MySQL Tables
		 $object[extension][cookie] =  Prefix for Cookies
	*/
?>
	
	// Javascript Code Injecting at Example Extension (Restricted)