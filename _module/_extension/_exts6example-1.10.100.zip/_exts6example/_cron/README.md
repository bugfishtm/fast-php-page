# Cronjob Code Injection

Use the Administrator Module to see how Code Injections work. You can find different Examples in the administrator Module which are directly working here even if this is an extension module.