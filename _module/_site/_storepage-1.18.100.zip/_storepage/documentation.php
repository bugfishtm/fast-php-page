<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); }
?>	
             <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">Documentation</h1>
                    </div>
                </div>
            </div>         
		
			<div class="col-12 mb-2 pb-0">
				<div class="card border-light shadow-sm components-section pb-0">
					<div class="card-body pb-0">
						<h2 class="h5">bugfishCMS</h2>
						<p>
							Explore our comprehensive guides to install, use, and extend BugfishCMS. Find step-by-step instructions, best practices, and tips to make the most out of your BugfishCMS experience.<br />
							<a href="https://bugfishtm.github.io/bugfish-cms" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Mirror 1</a>
							<a href="https://bugfish-github.de/bugfish-cms" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Mirror 2</a>
						</p>
					</div>
				</div>
			</div>
			<div class="col-12 mb-2 pb-0">
				<div class="card border-light shadow-sm components-section pb-0">
					<div class="card-body pb-0">
						<h2 class="h5">Bugfish Framework</h2>
						<p>
							Access detailed guides on the Bugfish Framework, the powerful backend integrated with BugfishCMS. Discover how to leverage its extensive functionality for active development, including setup, usage, and advanced customization tips.<br />
							<a href="https://bugfishtm.github.io/bugfish-framework" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Mirror 1</a>
							<a href="https://bugfish-github.de/bugfish-framework" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Mirror 2</a>
						
						
						</p>
					</div>
				</div>
			</div>
			<div class="col-12 mb-4 pb-0">
				<div class="card border-light shadow-sm components-section pb-0">
					<div class="card-body pb-0">
						<h2 class="h5">Tutorial Videos</h2>
						<p>
							Watch our playlist of tutorial videos on BugfishCMS. Learn how to install, use, and extend BugfishCMS with step-by-step video guides and expert tips.<br />
							<a href="https://www.youtube.com/playlist?list=PL6npOHuBGrpAfrpUzQPTOWdqoCnhq1oP0" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Tutorials</a>
						</p>
					</div>
				</div>
			</div>
			