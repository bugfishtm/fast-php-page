<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } ?>	
              <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">Download</h1>
                    </div>
                </div>
            </div>       
			<?php
				// Folder containing the files
				$folder = $object["path"].'/_store/_core/';

				// Get all files in the folder
				$files = glob($folder . '*.zip');

				// Array to store version numbers
				$versions = [];

				// Function to extract version number from filename
				function extractVersion($filename) {
					preg_match('/(\d+\.\d+)/', $filename, $matches);
					return $matches[1];
				}


				// Extract version numbers from filenames
				foreach ($files as $file) {
					//$version = extractVersion(basename($file));
					$version = basename($file);
					$versions[] = $version;
				}

				// Sort the version numbers in descending order
				$versions = array_reverse($versions);
			?>	
            <div class="row mb-0">
                <div class="col-12 col-xl-4 mb-4">
					<div class="card border-0 shadow">
						<div class="card-body ">
							<h2 class="fs-5 fw-bold mb-1">Latest Release</h2>
						 <?php if(count($versions) > 0) { ?>   <p>Here you can download the latest version of the CMS. Explore our ever-expanding "<b><a href="./?l1=modules">Extensions</a></b>"! For more information, select a module from the list below or to the right (depending on your screen size). If you have any issues, feel free to contact us using the "<b><a href="./?l1=support">How to get help</a></b>" Section. Developer and user documentation can be found in our "<b> <a href="./?l1=documentation">Documentation</a></b>" section! It is recommended to download the full package as the Source Package only contains the source code and no example and documentation files.<br /><a style="margin-bottom: 5px;margin-top: 5px;" href="https://github.com/bugfishtm/bugfish-cms/archive/refs/heads/main.zip" rel="noopener" class="btn btn-info">Download Full Package</a> <a style="margin-bottom: 5px; margin-top: 5px;" href="./_store/_core/<?php echo $versions[0]; ?>" class="btn btn-primary">Download Source</a></p> <?php } else { ?><p>There is currently no release available to download!</p>  <?php }  ?>
							<div class="d-block">
								<div class="d-flex align-items-center me-5">
									<div class="icon-shape icon-sm bg-light rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#000000"><path d="M280-280h400v-80H280v80Zm200-120 160-160-56-56-64 62v-166h-80v166l-64-62-56 56 160 160Zm0 320q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Latest Release</label><br />
										<span class="h4 mb-0"><?php if(count($versions) > 0) { echo substr(@$versions[0] ?? '', 0, -4); } else { echo "Not available"; } ?></span>
									</div>
								</div>
								<div class="d-flex align-items-center pt-3">
									<div class="icon-shape icon-sm bg-light rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#000000"><path d="M120-560v-240h80v94q51-64 124.5-99T480-840q150 0 255 105t105 255h-80q0-117-81.5-198.5T480-760q-69 0-129 32t-101 88h110v80H120Zm2 120h82q12 93 76.5 157.5T435-204l48 84q-138 0-242-91.5T122-440Zm412 70-94-94v-216h80v184l56 56-42 70ZM719 0l-12-60q-12-5-22.5-10.5T663-84l-58 18-40-68 46-40q-2-13-2-26t2-26l-46-40 40-68 58 18q11-8 21.5-13.5T707-340l12-60h80l12 60q12 5 23 11.5t21 14.5l58-20 40 70-46 40q2 13 2 25t-2 25l46 40-40 68-58-18q-11 8-21.5 13.5T811-60L799 0h-80Zm40-120q33 0 56.5-23.5T839-200q0-33-23.5-56.5T759-280q-33 0-56.5 23.5T679-200q0 33 23.5 56.5T759-120Z"/></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Latest Changelog</label>
										<p style="font-size: 12px;"><?php if(file_exists($object["path"]."/_store/_core-cl/".substr(@$versions[0] ?? '', 0, -4).".html")) { require_once($object["path"]."/_store/_core-cl/".substr(@$versions[0] ?? '', 0, -4).".html"); } else { echo "Not available"; } ?></p>
									</div>
								</div>
								<div class="d-flex align-items-center pt-3">
									<div class="icon-shape icon-sm bg-light rounded me-3 text-dark">
										<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#000000"><path d="m612-292 56-56-148-148v-184h-80v216l172 172ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 320q133 0 226.5-93.5T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160Z"/></svg></div>
									<div class="d-block">
										<label class="mb-0">Project Uptime</label><br />
										<span class=" h4 mb-0" id="countup">Please Wait...</span>
									</div>
								</div>
								<p class="mt-3 mb-1">We will very appreciate support for this project on "<b><a href="https://www.patreon.com/Bugfish" rel="noopener" target="_blank">Patreon</a></b>"!</p>
							</div>
						</div>
					</div>
                </div>
				<script>
					// Specify the target date
					const targetDate = new Date('2012-12-21T00:00:00');

					// Function to update the countdown
					function updateCountup() {
						const currentDate = new Date();
						const timeDifference = currentDate - targetDate;

						// Calculate elapsed time
						const milliseconds = Math.abs(timeDifference);
						const seconds = Math.floor(milliseconds / 1000) % 60;
						const minutes = Math.floor(milliseconds / (1000 * 60)) % 60;
						const hours = Math.floor(milliseconds / (1000 * 60 * 60)) % 24;
						const days = Math.floor(milliseconds / (1000 * 60 * 60 * 24));

						// Display the elapsed time
						const countdownElement = document.getElementById('countup');
						countdownElement.innerHTML = `${days} days`;
					}

					// Update the countdown every second
					setInterval(updateCountup, 1000);

					// Initial call to update countdown
					updateCountup();
				</script>		
                <div class="col-12 col-xl-8">	
					<div class="col-12 mb-4">
						<div class="card border-0 shadow">
							<div class="card-header">
								<div class="row align-items-center">
									<div class="col">
										<h2 class="fs-5 fw-bold mb-0">Archived Source Packages</h2>
										<small>Here you can see and access different bugfishCMS releases. The first 3 digits represent the core release number (x.xx.), the digits after the _ sign represent the integrated administrator module release version. If the administrator release version is 0.00.000, than there is no administrator module included in the release file. These packages do only contain the source and no additional data like documentation and other! Download the full package to receive all files of this project.</small>
									</div>
								</div>
							</div>			
							<div class="table-responsive">
								<table class="table align-items-center table-flush" style="max-width: 100%;">
									<thead class="thead-light">
									<tr>
										<th class="border-bottom" scope="col">Version</th>
										<th class="border-bottom" scope="col">Download</th>
									</tr>
									</thead>
									<tbody>
									<?php $run = false; foreach($versions as $key => $value) { $run = true; ?>
									<tr>
										<th class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;">
											<b><?php echo $value; ?></b>
											<p style="font-size: 12px; padding-bottom: 5px;margin-bottom: 0px;"><?php if(file_exists($object["path"]."/_store/_core-cl/".substr($value, 0, -4).".html")) { require($object["path"]."/_store/_core-cl/".substr($value, 0, -4).".html"); } else { echo "Not available"; } ?></p>
										</th>
										<td class="fw-bolder text-gray-500">
										   <a href="./_store/_core/<?php echo $value; ?>" class="btn btn-primary">Download Source</a>
										</td>
									</tr>
									<?php } 
									if(!$run) { 
										?>
											<tr>
												<td class="text-gray-900" scope="row" colspan="2">
													There is currently no core version available!
												</td>
											</tr>											
										
										<?php
									}
									?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
            </div>