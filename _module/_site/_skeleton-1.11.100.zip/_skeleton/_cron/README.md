# 📁 _cron Folder

## 📄 Overview
The `_cron` folder is dedicated to storing cron jobs that are executed at various intervals. This folder is organized into subfolders representing different time periods, allowing for systematic scheduling and execution of tasks.

## 📅 Subfolders
Each subfolder within the `_cron` folder corresponds to a specific cron job interval. These subfolders include:

- **`_daily`**: Contains cron jobs that run daily.
- **`_monthly`**: Contains cron jobs that run monthly.
- **`_hourly`**: Contains cron jobs that run hourly.
- **`_weekly`**: Contains cron jobs that run weekly.
- **`_yearly`**: Contains cron jobs that run yearly.

## 🔄 Auto-Inclusion of Cron Jobs
Developers can add their own cron job files in the appropriate subfolders. The files must follow the naming convention `cron.*.php` to be auto-included by the core system.

## 📂 Folder Contents
The typical files you might find in this folder include:
- **PHP Files**: Containing the code to be executed at the specified intervals.

## 🛠️ How to Use
1. **Create Your Cron Job Files**:
   - Identify the appropriate interval subfolder for your cron job.
   - Name your file following the convention `cron.*.php`.
2. **Auto-Inclusion**:
   - Place your file in the relevant subfolder. The core system will automatically include and execute these files at the specified intervals.
3. **Coding Your Cron Job**:
   - Ensure your PHP code is robust and performs the intended tasks efficiently.

## ⚠️ Important Notes
- **Naming Convention**: Adhere to the `cron.*.php` naming convention to ensure your cron jobs are auto-included.
- **Interval Placement**: Place your cron job in the correct interval subfolder to ensure it runs at the desired frequency.

## ❓ Need Help?
For any assistance or further information on how to use and develop cron jobs in the `_cron` folder, please refer to the BugfishCMS documentation or reach out to the support team.

Happy Coding!  
Bugfish <3