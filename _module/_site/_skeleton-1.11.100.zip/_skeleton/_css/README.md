# 📁 _css Folder

## 📄 Overview
The `_css` folder is designated for storing CSS files that are automatically loaded into BugfishCMS via the HTML include at `/core/stylesheet.php`. This folder helps manage CSS code required for various styling needs depending on the user's login status.

## 🔄 Auto-Loading Stylesheets
CSS files in this folder are auto-loaded based on specific naming conventions:

- **`css.global.*`**: These files are included for both logged-in and non-logged-in users.
- **`css.restricted.*`**: These files are included only when the user is logged in.
- **`css.public.*`**: These files are included only when the user is not logged in.

## 📂 Folder Contents
The typical files you might find in this folder include:
- **CSS Files**: Containing styles relevant to the CMS functionalities.
- **PHP Files**: These can also be used to include PHP code, with settings and initializations already handled at file load-up.

## 🛠️ How to Use
1. **Create Your CSS Files**:
   - For global styles: Name them as `css.global.*.css`.
   - For restricted styles: Name them as `css.restricted.*.css`.
   - For public styles: Name them as `css.public.*.css`.
2. **Auto-Loading**:
   - Place your files in the `_css` folder and they will be automatically included based on the user's login status.
3. **PHP Integration**:
   - If you need to include PHP code, create `.php` files and place them in this folder. Settings and initializations are already done at file load-up, so you can directly add your PHP logic.

## ⚠️ Important Notes
- **Naming Convention**: Adhere to the specified naming conventions to ensure correct auto-loading of your stylesheets.
- **Dependency Management**: Ensure that your stylesheets do not have unresolved dependencies which could cause issues during runtime.

## ❓ Need Help?
For any assistance or further information on how to use and develop stylesheets in the `_css` folder, please refer to the BugfishCMS documentation or reach out to the support team.

Happy Coding!  
Bugfish <3