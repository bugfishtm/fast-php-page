# 🌐 Site Module Example

## 🧩 **General Information**

Site modules can run as standalone websites or alongside other installed website modules. They can be distributed across various domains and virtual hosts, offering full control over administration needs.

- **Naming Conventions**: Module names (`RNAME`) must start with a lowercase letter (a-z) and contain a maximum of 10 characters.
- **Extendibility**: Site modules can be extended using script or extension modules.

For detailed guidance, refer to our example Site Module in the [Github repository](#).

## 🗂️ **Folder Structure**

Organize your site module ZIP file as follows. Replace `RNAME` with your module name.

### CMS Cronjob Injection

You will have the following variables to work with, relative to your site module:

- `$object["cron_mail"]`: Current site module's Cron Mail Object.
- `$object["cron_var"]`: Current site module's Cron Variables Object.
- `$object["cron_mail_template"]`: Current site module's Cron Mail Template Object.
- `$hive_mode_cron`: Current Cron Hive Mode Folder Name.

```
./RNAME/
├── _cron/
│   ├── _daily/* (Daily cronjob injection scripts)
│   ├── _hourly/* (Hourly cronjob injection scripts)
│   ├── _weekly/* (Weekly cronjob injection scripts)
│   ├── _yearly/* (Yearly cronjob injection scripts)
│   └── _monthly/* (Monthly cronjob injection scripts)
```

### CSS Injection Folder

```
./RNAME/_css/ (Add CSS files here)
```

### Administrator Module Hooks

```
./RNAME/_admin/
├── mod_setting.php (Module settings script)
└── mod_index.php (Administration module load script)
```

### JS Injection Folder

```
./RNAME/_js/ (Add JS files here)
```

### Language Loadup Folder

```
./RNAME/_lang/ (Add language files here)
```

### WFC Loadup Folder

```
./RNAME/_wfc/ (Add site widgets here)
```

### Functions Loadup Folder

```
./RNAME/_lib/ (Add library files here)
```

### MySQL Loadup Folder

```
./RNAME/_mysql/ (Add SQL files here for auto-installation)
```

### Themes Loadup Folder

```
./RNAME/_theme/ (Add theme files here)
```

### Update Loadup Folder

```
./RNAME/_update/ (Add update files here)
```

### Config Loadup Folder

```
./RNAME/_config/
├── config_pre.php (Pre-startup configuration)
├── config_post.php (Post-startup configuration)
├── config_global_pre.php (Global pre-startup configuration)
├── config_global_post.php (Global post-startup configuration)
├── permission.php (Permission declarations)
└── config.php (Main configuration file)
```

### Site Modules Index Files

```
./RNAME/
├── load.php (Site loadup file)
├── version.php (Versioning info)
├── changelog.php (Changelog info)
└── preview.jpg (Preview image)
```

Happy Coding!  
Bugfish <3