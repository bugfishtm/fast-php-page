# 📁 _lang Folder

## 📄 Overview
The `_lang` folder stores language files used by BugfishCMS, organized according to the language arrays set in the `config.php` file. These files facilitate multi-language support within the CMS, allowing for localization and internationalization of content.

## 🌐 Language Files
Language files in this folder are named according to the language array set in `config.php`. These files contain translations and language-specific settings for different parts of the CMS.

## 📂 Folder Contents
The `_lang` folder includes files such as:
- **Example Language Files**: These files demonstrate how to structure translations for different languages within BugfishCMS.

## 🛠️ How to Use
1. **Understanding Language Arrays**:
   - Refer to the `config.php` file to identify the language arrays used in BugfishCMS.
2. **Creating Language Files**:
   - Name your language files according to the language array names specified in `config.php`.
   - Inside each file, define key-value pairs where keys represent constants or identifiers in the CMS, and values represent the translated text in the respective language.
3. **Integration**:
   - Ensure that the language files are correctly linked within your CMS setup to provide seamless language switching and localization.

## 📄 Example File Structure
For example, if your `config.php` defines language arrays like `$lang['en']`, `$lang['fr']`, `$lang['de']`, your `_lang` folder might contain:
- **`en`**: English language file.
- **`fr`**: French language file.
- **`de`**: German language file.
  
Each of these files would contain translations and language-specific settings relevant to BugfishCMS.

## ⚠️ Important Notes
- **Consistency**: Maintain consistency in naming and structure across your language files to ensure smooth functionality.
- **Updating**: Regularly update language files as your CMS evolves or expands to include new features or content.

## ❓ Need Help?
For any assistance or further information on how to manage language files in the `_lang` folder, please refer to the BugfishCMS documentation or reach out to the support team.

Happy Coding!  
Bugfish <3