# 📁 _mysql Folder

## 📄 Overview
The `_mysql` folder is used for managing database tables within BugfishCMS. It contains PHP files that automate the creation of database tables if they do not already exist. This feature helps streamline the setup and maintenance of the CMS database structure.

## ⚙️ Auto-Execution of SQL Files
Files in this folder follow a specific naming convention: `mysql.*.php`. These files are responsible for defining database tables. If a table named like the file (without the `mysql.` prefix) does not exist in the database, the corresponding PHP file will automatically execute to create it.

## 📂 Folder Contents
The `_mysql` folder typically includes:
- **PHP Files**: Named `mysql.*.php`, each corresponding to a database table definition.

## 🛠️ How to Use
1. **Naming Convention**:
   - Name your PHP files in the format `mysql.*.php`, where `*` represents a descriptive name related to the table it creates.
2. **Table Creation**:
   - Inside each PHP file, define the SQL statements necessary to create the corresponding database table.
   - Ensure that table names match the file names without the `mysql.` prefix.
3. **Auto-Execution**:
   - Upon CMS startup, these PHP files will be automatically executed if the corresponding tables do not already exist in the database.

## 📄 Example File Structure
For example, if your CMS requires tables named `users`, `posts`, and `comments`, your `_mysql` folder might contain:
- **`mysql.users.php`**: PHP file creating the `users` table.
- **`mysql.posts.php`**: PHP file creating the `posts` table.
- **`mysql.comments.php`**: PHP file creating the `comments` table.

Each of these files would contain SQL statements to create the respective tables when needed.

## ⚠️ Important Notes
- **Database Connectivity**: Ensure that your PHP files include appropriate database connection settings (`mysqli`, PDO, etc.) to interact with the database.
- **Security**: Validate and sanitize input within SQL statements to prevent SQL injection vulnerabilities.

## ❓ Need Help?
For any assistance or further information on how to manage database tables using files in the `_mysql` folder, please refer to the BugfishCMS documentation or reach out to the support team.

Happy Coding!  
Bugfish <3