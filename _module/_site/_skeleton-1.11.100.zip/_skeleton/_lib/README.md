# 📁 _lib Folder

## 📄 Overview
The `_lib` folder is a critical component of BugfishCMS. It contains library files that provide essential functionalities and utilities required by the CMS during its operation.

## 🔄 Auto-Inclusion on Startup
Files in this folder that follow the naming pattern `lib.*.php` will be automatically included during the site startup, prior to the initialization phase. This ensures that necessary libraries are available for the CMS right from the beginning.

## 📂 Folder Contents
The typical files you might find in this folder include:
- **Library PHP Files**: These are PHP files named in the format `lib.*.php`, containing reusable functions and classes.
- **Utility Scripts**: Additional scripts that support various CMS operations.

## 🛠️ How to Use
1. **Create Your Library Files**: Add PHP files in the `_lib` folder, following the naming convention `lib.*.php`.
2. **Automatic Inclusion**: During site startup, BugfishCMS will automatically include these files before the initialization process begins.
3. **Development**: Ensure that the library files contain robust and reusable code to be utilized across different parts of your CMS.

## ⚠️ Important Notes
- **Naming Convention**: Adhere strictly to the `lib.*.php` naming convention for the auto-inclusion mechanism to work correctly.
- **Dependencies**: Be mindful of dependencies within your library files to avoid issues during the startup phase.

## ❓ Need Help?
For any assistance or further information on how to use and develop library files in the `_lib` folder, please refer to the BugfishCMS documentation or reach out to the support team.

Happy Coding!  
Bugfish <3