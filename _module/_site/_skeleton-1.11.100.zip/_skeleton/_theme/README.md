# 📁 User Template Files

## 📄 Overview
This folder is dedicated to storing files related to the users' templates. These files are essential for defining the appearance and structure of the user interface in BugfishCMS.

## 🚫 Not for CMS Auto-Load
Please note that this folder is **not** connected to any CMS auto-load functionalities. The files here will not be automatically loaded by the CMS system. Manual integration is required.

## 📂 Folder Contents
The typical files you might find in this folder include:
- **HTML Files**: These files define the layout of the user interface.
- **CSS Files**: These files contain the styling rules for the user interface.
- **JavaScript Files**: These scripts provide dynamic behaviors for the user interface.

## 🛠️ How to Use
1. **Create Your Template Files**: Add your HTML, CSS, and JavaScript files in this folder.
2. **Manual Integration**: Ensure to manually link these files within your CMS configuration or theme settings.
3. **Testing**: Always test your template files to ensure they work as expected with the rest of your CMS setup.

## ❓ Need Help?
For any assistance or further information on how to use these template files, please refer to the BugfishCMS documentation or reach out to the support team.

Happy Coding!  
Bugfish <3