# 📁 _update Folder

## 📄 Overview
The `_update` folder is used for managing database updates within BugfishCMS. It contains PHP files that automate the process of updating the database schema and content to match the current module build number. This feature ensures smooth transitions and upgrades across different versions of the CMS.

## 🔧 Handling Updates
Files in this folder follow a specific naming convention: `[build_number].php`. These files are responsible for implementing database changes necessary to upgrade from one build version to the next. If the current installed build version of the CMS does not match the deployed module build number, update files between these versions will be executed sequentially to bring the database up to date.

## 📂 Folder Contents
The `_update` folder typically includes:
- **PHP Update Files**: Named with the build number they update to, e.g., `201.php`, `250.php`.

## 🛠️ How to Use
1. **File Naming**:
   - Name your PHP update files with the build number they upgrade to. For instance, `201.php` updates the database schema to version 201.
2. **Version Check**:
   - During CMS initialization, compare the current installed build number with the deployed module build number.
   - Sequentially execute PHP update files from the current build number up to the deployed module build number to apply necessary database changes.

## 📄 Example File Structure
For example, if your CMS has build versions from 100 to 200, your `_update` folder might contain:
- **`201.php`**: Updates for build version 201.
- **`250.php`**: Updates for build version 250.

Each PHP file in this folder would contain SQL statements or PHP code to modify the database schema or content as needed for that specific build version.

## ⚠️ Important Notes
- **Sequential Execution**: Ensure that update files are executed in the correct order, from the current installed build version to the deployed module build number.
- **Backup**: Always back up your database before applying updates to mitigate potential data loss or corruption.

## ❓ Need Help?
For any assistance or further information on how to manage database updates using files in the `_update` folder, please refer to the BugfishCMS documentation or reach out to the support team.

Happy Coding!  
Bugfish <3