# 📁 _config Folder

## 📄 Overview
The `_config` folder contains configuration files that are crucial for initializing different sections of BugfishCMS. These files are loaded at various stages of initialization to define settings, parameters, and behaviors.

## 📂 Folder Contents
See example configuration files present in this folder.

Happy Coding!  
Bugfish <3 