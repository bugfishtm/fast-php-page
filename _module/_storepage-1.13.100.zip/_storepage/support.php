<?php
	/* 	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  	
							www.bugfish.eu
							
	    Bugfish Fast PHP Page Framework
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); }
?>          

            <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">How to get help?</h1>
                    </div>
                </div>
            </div>

			<div class="col-12 mb-2 pb-0">
				<div class="card border-light shadow-sm components-section pb-0">
					<div class="card-body pb-0">
						 <h2 class="h5">Github Issues</h2>
						 <p>To report bugs or issues with BugfishCMS, please visit our <b><a href="https://github.com/bugfishtm/bugfish-cms/issues" rel="nofollow noopener noreferrer" target="_blank">GitHub Issues</a></b> page. Here, you can create a new issue or contribute to existing discussions to help us improve BugfishCMS.<br /><a class="btn btn-primary" href="https://github.com/bugfishtm/bugfish-cms/issues" rel="nofollow noopener noreferrer" target="_blank">GitHub Issues</a></p>
					</div>
				</div>
			</div>
			
			<div class="col-12 mb-2 pb-0">
				<div class="card border-light shadow-sm components-section pb-0">
					<div class="card-body pb-0">
						 <h2 class="h5">Bugfish Forum</h2>
						 <p>If you prefer community-based support or want to engage in discussions with other BugfishCMS users, you can join our <b><a href="https://bugfish.eu/forum" rel="nofollow noopener noreferrer" target="_blank">Bugfish Forum</a></b>. Share your experiences, ask questions, and connect with other users.<br /><a href="https://bugfish.eu/forum" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Bugfish Forum</a></p>
					</div>
				</div>
			</div>
			
			<div class="col-12 mb-4">
				<div class="card border-light shadow-sm components-section">
					<div class="card-body pb-0">
						 <h2 class="h5">Contact Mail</h2>
						 <p>For direct assistance or inquiries, feel free to contact us via email at <b><a href="mailto:requests@bugfish.eu" rel="nofollow noopener noreferrer">requests@bugfish.eu</a></b>. We're here to help with any questions, concerns, or feedback you may have regarding BugfishCMS.<br /><a href="mailto:requests@bugfish.eu" rel="nofollow noopener noreferrer" class="btn btn-primary">requests@bugfish.eu</a></p>
					</div>
				</div>
			</div>
					
					