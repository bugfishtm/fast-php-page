<?php
	/* 	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  	
							www.bugfish.eu
							
	    Bugfish Fast PHP Page Framework
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } ?>	
            <div class="py-4">
                <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
                    <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
                        <li class="breadcrumb-item">
                            <a href="#">
                                <svg class="icon icon-xxs" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                            </a>
                        </li>
                        <li class="breadcrumb-item"><a href="#">Store</a></li>
                    </ol>
                </nav>
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">Store</h1>
                    </div>
                </div>
            </div>        	
			<?php
				// Folder containing the files
				$mods = $object["mysql"]->select("SELECT * FROM "._TABLE_STORE_." WHERE is_active = 1 AND mod_type <> 3 ORDER BY mod_rname, mod_version, mod_build DESC", true);
				$last = false;
				if(is_array($mods)) {
					$mods = array_reverse($mods);
					foreach($mods as $key => $value) {
						if($value["mod_rname"] == $last) { 
							continue;
						}
						$last = $value["mod_rname"];
			?>			




				<div class="col-12 mb-4">
					<div class="card border-0 shadow">
						<div class="card-header store_hoverhide" onclick="showhide_store($(this));">
							<div class="row align-items-center">
								<div class="col">
									<h2 class="fs-5 fw-bold mb-0"><?php echo htmlspecialchars($value["mod_name"] ?? ''); ?></h2>
									<?php echo htmlspecialchars($value["mod_short"] ?? ''); ?>
								</div>
							</div>
						</div>
						<div class="card-body store_autohide">
							<?php if(file_exists("./_store/_module-img/".$value["mod_rname"]."-".$value["mod_version"].".jpg")) { ?><div style="float: left;padding: 15px; max-width: 100%; width: 200px;padding-top: 0px; padding-left: 0px;">
								<img src="./_store/_module-img/<?php echo $value["mod_rname"]."-".$value["mod_version"]; ?>.jpg">
							</div> <?php } ?>
							<div class="float: left;">
								<?php echo htmlspecialchars($value["mod_description"] ?? '');?>
							</div><br clear="both">
							<div class="">
								<b>Latest Version</b>: <?php echo htmlspecialchars($value["mod_version"] ?? '');?>
								<small>[<b>Build</b>: <?php echo htmlspecialchars($value["mod_build"] ?? ''); ?>]</small><br />
								<b>Autor</b>: <?php echo htmlspecialchars($value["mod_autor"] ?? ''); ?> 
								<small>[<?php echo htmlspecialchars($value["mod_website"] ?? ''); ?>]</small><br /><br />
				
								<b>Download</b>:
								<table>
									<?php
										foreach($mods as $keyx => $valuex) {
											if($value["mod_rname"] != $valuex["mod_rname"] /*OR ($valuex["mod_version"] == $value["mod_version"] AND $valuex["mod_build"] == $value["mod_build"]) */) { continue; }
											?>
												<tr>
													<td style="min-width: 100px; max-width: 40%;"><?php echo $valuex["mod_version"]; ?></td>
													<td><a class="btn btn-primary" href="./_store/_module-zip/<?php echo $valuex["mod_rname"]."-".$valuex["mod_version"].".zip"; ?>">Download</a></td>
												</tr>
											<?php
										}
									?>
								</table>
							</div>
						</div>
					</div>
				</div>





			<?php
					}
				} else { 
			?>			
				<div class="col-12 mb-4">
					<div class="card border-0 shadow">
						<div class="card-header">
							<div class="row align-items-center">
								<div class="col">
									<h2 class="fs-5 fw-bold mb-0">Currently no items available!</h2>
									There are currently no store items available, please come back later!
								</div>
							</div>
						</div>
						<div class="table-responsive">

						</div>
					</div>
				</div>
			<?php
				}
			?>			
			
			<style>
				.store_act {
					background: #1F2937 !important;
					color: white !important;
					cursor: pointer;
				}
				.store_hoverhide:hover {
					background: #1F2937 !important;
					color: white !important;
					cursor: pointer;
				}
				
				.store_hoverhide:hover h2 {
					background: #1F2937 !important;
					color: white !important;
				}
			</style>
			
			<script>
				$(".store_autohide").toggle();
				function showhide_store(thisvar) {
					thisvar.next().toggle();
					if(thisvar.attr('tts') == '1') { 
						thisvar.css('background-color', '#FFFFFF');
						thisvar.css('color', '#000000');
						thisvar.children().removeClass('store_act');
						thisvar.children().children().children().removeClass('store_act');
						thisvar.attr('tts', '0');
					} else {
						thisvar.css('background-color', '#1F2937');
						thisvar.addClass('color', 'white !important');
						thisvar.children().addClass('store_act');
						thisvar.children().children().children().addClass('store_act');
						thisvar.attr('tts', '1');
					}
				}
			</script>