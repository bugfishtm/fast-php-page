<?php
	/* 	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  	
							www.bugfish.eu
							
	    Bugfish Fast PHP Page Framework
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		// Configuration Injection to be loaded before Initializations, before global_post injections!
	*/ if(!is_array($object)) { http_response_code(404); Header("Location: ../"); exit(); }
	#####################################################################################
	## Language Selection Settings
	#####################################################################################
		// Array for Language / Chooser in topbar Changer - Needs Fitting Configuration for Language Availability
		$lang_ar = array();
		$lang_ar[0]["current_img"] = _HIVE_URL_REL_."/_core/_vendor/country-flags-icons/png/"._HIVE_LANG_.".png";
		$lang_ar[0]["ident"] = "en";
		$lang_ar[0]["img"] = _HIVE_URL_REL_."/_core/_vendor/country-flags-icons/png/en.png";
		$lang_ar[0]["name"] = "English";

	#####################################################################################
	## Navigation Selection Settings
	#####################################################################################	
	
		// Main Menue (Used in Dashboard Themes)	
		$object["nav"] = array();
		
		$object["nav"][0]["nav_title"] = "Start";	
		$object["nav"][0]["nav_loc"] = hive_get_url_rel(array("startpage", false, false));
		$object["nav"][0]["nav_sub"] = false;
		$object["nav"][0]["nav_act"] = "startpage";
		$object["nav"][0]["nav_img"] = "bx bx-cloud-download";
	
		$object["nav"][1]["nav_title"] = "Store";
		$object["nav"][1]["nav_sub"] = false;
		$object["nav"][1]["nav_loc"] = hive_get_url_rel(array("modules", false, false));
		$object["nav"][1]["nav_act"] = "modules";	
		$object["nav"][1]["nav_img"] = "bx bxs-dashboard";
	
		$object["nav"][2]["nav_title"] = "Documentation";
		$object["nav"][2]["nav_sub"] = false;
		$object["nav"][2]["nav_loc"] = hive_get_url_rel(array("documentation", false, false));
		$object["nav"][2]["nav_act"] = "documentation";	
		$object["nav"][2]["nav_img"] = "bx bx-book";	
	
		$object["nav"][3]["nav_title"] = "Support";
		$object["nav"][3]["nav_sub"] = false;
		$object["nav"][3]["nav_loc"] = hive_get_url_rel(array("support", false, false));
		$object["nav"][3]["nav_act"] = "support";	
		$object["nav"][3]["nav_img"] = "bx bx-support";	
	
		$object["nav"][4]["nav_sub"] = false;	
		$object["nav"][4]["nav_img"] = "bx bx-code-curly"; # Box Icon Image Class
		$object["nav"][4]["nav_title"] = "Github"; # Nav Name
		$object["nav"][4]["nav_act"] = "github";	# Show as Active in Nav on Which First Location?
		$object["nav"][4]["nav_loc"] = "https://github.com/bugfishtm/bugfish-cms"; # Location
		$object["nav"][4]["nav_target"] = "_blank"; # Location
		
		$object["nav"][5]["nav_sub"] = false;	
		$object["nav"][5]["nav_img"] = "bx bx-shield"; # Box Icon Image Class
		$object["nav"][5]["nav_title"] = "Privacy"; # Nav Name
		$object["nav"][5]["nav_act"] = "privacy";	# Show as Active in Nav on Which First Location?
		$object["nav"][5]["nav_loc"] = hive_get_url_rel(array("privacy", false, false)); # Location
		
		$object["nav"][6]["nav_title"] = "Imprint"; # Nav Name
		$object["nav"][6]["nav_img"] = "bx bxs-user-detail"; # Box Icon Image Class
		$object["nav"][6]["nav_act"] = "impressum";	# Show as Active in Nav on Which First Location?
		$object["nav"][6]["nav_sub"] = false;	
		$object["nav"][6]["nav_loc"] = hive_get_url_rel(array("impressum", false, false));

	#####################################################################################
	## Store Page Configuration
	#####################################################################################
		$object["var"]->setup("_HIVE_TITLE_",  "bugfishCMS Store", "Title for the Website");
		$object["var"]->setup("_STORE_IMPRESSUM_",  "<b>Impressum</b> Information", "Impressum for the Website");
		$object["var"]->setup("_STORE_PRIVACY_",  "<b>Privacy</b> Information", "Privacy Info for the Website");
		$object["var"]->setup("_STORE_FOOTER_",  "Footer <b>Text</b>", "Footer for the Website");
		$object["var"]->init_constant();