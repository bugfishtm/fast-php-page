<?php
	/* 	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  	
							www.bugfish.eu
							
	    Bugfish Fast PHP Page Framework
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		// Initialize File will be loaded if site Mode is Active
	*/
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); }
	switch(_HIVE_URL_CUR_[0]) {
		case false: case "":
			Header("Location: ./?"._HIVE_URL_GET_[0]."=startpage");
			break;
	}
	
	switch(_HIVE_URL_CUR_[0]) {
		case "startpage":
				hive__volt_header($object, "Download", '<link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="download, homepage, info, bugfishcms"><meta property="og:type" content="website">    <meta property="og:description" content="Discover our Core CMS, learn about its features, and download the latest version."><meta property="og:title" content="Download'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta name="description" content="Discover our Core CMS, learn about its features, and download the latest version.">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/startpage.php");
		break;	
		case "modules":
				hive__volt_header($object, "Store", '<link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="store, extensions, modules, bugfishcms"><meta property="og:type" content="website"><meta name="description" content="Explore and download extensions for our CMS to enhance its functionality."><meta property="og:description" content="Explore and download extensions for our CMS to enhance its functionality."><meta property="og:title" content="Store'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/store.php");
		break;		
		case "support":
				hive__volt_header($object, "Support", '<link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="support, help, bugfishcms"><meta property="og:type" content="website"><meta property="og:description" content="Get help and support for our products and services. Contact our support team for assistance."><meta property="og:title" content="Support'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta name="description" content="Get help and support for our products and services. Contact our support team for assistance.">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/support.php");
		break;			
		case "documentation":
				hive__volt_header($object, "Documentation", '<link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="documentation, help, bugfishcms"><meta property="og:type" content="website"><meta name="description" content="Access comprehensive guides and documentation for using our product."><meta property="og:description" content="Access comprehensive guides and documentation for using our product."><meta property="og:title" content="Documentation'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/documentation.php");
		break;			
		case "privacy":
				hive__volt_header($object, "Privacy", '<link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="privacy, bugfishcms"><meta property="og:type" content="website"><meta name="description" content="Read our privacy policy to understand how we handle your personal data and protect your privacy."><meta property="og:title" content="Privacy'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta property="og:description" content="Read our privacy policy to understand how we handle your personal data and protect your privacy.">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/privacy.php");
		break;			
		case "impressum":
				hive__volt_header($object, "Imprint", '<link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="imprint, owner, bugfishcms"><meta name="description" content="Find legal information and contact details in our Impressum."><meta property="og:description" content="Find legal information and contact details in our Imprint."><meta property="og:title" content="Imprint'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta property="og:type" content="website">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/impressum.php");
		break;	
		default:
				hive__volt_header($object, "Error 404", '<link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="noindex, nofollow">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				echo "<br />"; hive__volt_404($object, "Error 404", "Page not found!");	
	}	
	
	$object["eventbox"]->show("Close");
	x_cookieBanner(_HIVE_SITE_COOKIE_);
	hive__volt_footer($object, _STORE_FOOTER_);
