<?php
	/* 	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  	
							www.bugfish.eu
							
	    Bugfish Fast PHP Page Framework
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } ?>	
              <div class="py-4">
                <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
                    <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
                        <li class="breadcrumb-item">
                            <a href="#">
                                <svg class="icon icon-xxs" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                            </a>
                        </li>
                        <li class="breadcrumb-item"><a href="#">Start</a></li>
                    </ol>
                </nav>
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">Start</h1>
                    </div>
                </div>
            </div>               

            <div class="row mb-4">
                <div class="col-12 col-sm-16 col-xl-16 mb-0">
                    <div class="card border-0 shadow">
                        <div class="card-body pb-0">
                            <div class="row d-block d-xl-flex align-items-center">
                                <h2 class="h5">Introduction</h2>
								<p>Welcome to the bugfishCMS store, your hub for unlocking the full potential of your web projects. Browse through our collection of modules and core versions tailored to streamline your content management needs. Whether you're seeking enhanced functionality or seamless integration, bugfishCMS provides intuitive solutions for developers of all levels. Dive into our marketplace and discover the tools to elevate your digital presence. With bugfishCMS, innovation is just a download away.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

			<?php
				// Folder containing the files
				$folder = $object["path"].'/_store/_core/';

				// Get all files in the folder
				$files = glob($folder . '*.zip');

				// Array to store version numbers
				$versions = [];

				// Function to extract version number from filename
				function extractVersion($filename) {
					preg_match('/(\d+\.\d+)/', $filename, $matches);
					return $matches[1];
				}


				// Extract version numbers from filenames
				foreach ($files as $file) {
					//$version = extractVersion(basename($file));
					$version = basename($file);
					$versions[] = $version;
				}

				// Sort the version numbers in descending order
				$versions = array_reverse($versions);
			?>	
            <div class="row mb-0">
                <div class="col-12 col-xl-4 mb-4">
					<div class="card border-0 shadow">
						<div class="card-body ">
							<h2 class="fs-5 fw-bold mb-1">Download CMS</h2>
						 <?php if(count($versions) > 0) { ?>   <p>Here you can download the latest version of the CMS.<br /> <a href="./_store/_core/<?php echo $versions[0]; ?>" class="btn btn-primary">Download</a></p> <?php } else { ?><p>There is currently no release available to download!</p>  <?php }  ?>
							<div class="d-block">
								<div class="d-flex align-items-center me-5">
									<div class="icon-shape icon-sm icon-shape-danger rounded me-3">
										<svg fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 3a1 1 0 000 2v8a2 2 0 002 2h2.586l-1.293 1.293a1 1 0 101.414 1.414L10 15.414l2.293 2.293a1 1 0 001.414-1.414L12.414 15H15a2 2 0 002-2V5a1 1 0 100-2H3zm11 4a1 1 0 10-2 0v4a1 1 0 102 0V7zm-3 1a1 1 0 10-2 0v3a1 1 0 102 0V8zM8 9a1 1 0 00-2 0v2a1 1 0 102 0V9z" clip-rule="evenodd"></path></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Latest Release</label>
										<h4 class="mb-0"><?php if(count($versions) > 0) { echo substr($versions[0], 0, -4); } else { echo "Not available"; } ?></h4>
									</div>
								</div>
								<div class="d-flex align-items-center pt-3">
									<div class="icon-shape icon-sm icon-shape-purple rounded me-3">
										<svg fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z"></path></svg>                                        </div>
									<div class="d-block">
										<label class="mb-0">Releases Count</label>
										<h4 class="mb-0"><?php echo count($versions); ?></h4>
									</div>
								</div>
								<div class="d-flex align-items-center pt-3">
									<div class="icon-shape icon-sm icon-shape-purple rounded me-3">
										<svg fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z"></path></svg>                                        </div>
									<div class="d-block">
										<label class="mb-0">Project Uptime</label>
										<h4 class="mb-0" id="countup">Please Wait...</h4>
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
				<script>
					// Specify the target date
					const targetDate = new Date('2012-12-21T00:00:00');

					// Function to update the countdown
					function updateCountup() {
						const currentDate = new Date();
						const timeDifference = currentDate - targetDate;

						// Calculate elapsed time
						const milliseconds = Math.abs(timeDifference);
						const seconds = Math.floor(milliseconds / 1000) % 60;
						const minutes = Math.floor(milliseconds / (1000 * 60)) % 60;
						const hours = Math.floor(milliseconds / (1000 * 60 * 60)) % 24;
						const days = Math.floor(milliseconds / (1000 * 60 * 60 * 24));

						// Display the elapsed time
						const countdownElement = document.getElementById('countup');
						countdownElement.innerHTML = `${days} days`;
					}

					// Update the countdown every second
					setInterval(updateCountup, 1000);

					// Initial call to update countdown
					updateCountup();
				</script>		
                <div class="col-12 col-xl-8">	
					<div class="col-12 mb-4">
						<div class="card border-0 shadow">
							<div class="card-header">
								<div class="row align-items-center">
									<div class="col">
										<h2 class="fs-5 fw-bold mb-0">bugfishCMS Releases</h2>
										Here you can see and access different bugfishCMS releases. The first 3 digits represent the core release number (x.xx.), the digits after the _ sign represent the integrated administrator module release version. If the administrator release version is 0.00.000, than there is no administrator module included in the release file.
									</div>
								</div>
							</div>			
							<div class="table-responsive">
								<table class="table align-items-center table-flush">
									<thead class="thead-light">
									<tr>
										<th class="border-bottom" scope="col">Version</th>
										<th class="border-bottom" scope="col">Download</th>
									</tr>
									</thead>
									<tbody>
									<?php $run = false; foreach($versions as $key => $value) { $run = true; ?>
									<tr>
										<th class="text-gray-900" scope="row">
											<?php echo $value; ?>
										</th>
										<td class="fw-bolder text-gray-500">
										   <a href="./_store/_core/<?php echo $value; ?>" class="btn btn-primary">Download</a>
										</td>
									</tr>
									<?php } 
									if(!$run) { 
										?>
											<tr>
												<td class="text-gray-900" scope="row" colspan="2">
													There is currently no core version available!
												</td>
											</tr>											
										
										<?php
									}
									?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
            </div>