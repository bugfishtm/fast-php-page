Example of a Script module for Public and Restricted Pages.
See Documentation for more information in the official bugfishCMS Repository!