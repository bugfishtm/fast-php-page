<?php
	/* 	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  	
							www.bugfish.eu
							
	    Bugfish Fast PHP Page Framework
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/	
	$x = array();
	$x["rname"] 		= "_simple-backend";
	$x["version"] 		= "2.00";
	$x["build"] 		= "200";
	$x["singleuse"] 	= false;
	$x["cat"] 			= "dev";
	$x["lang"] 			= array("en");
	$x["license"] 		= "MIT";
	$x["autor"] 		= "Jan-Maurice Dahlmanns";
	$x["pseudo"] 		= "Bugfish";
	$x["mail"] 			= "requests@bugfish.eu";
	$x["website"] 		= "www.bugfish.eu";
	$x["name"] 			= "FP2: Simple Backend Interface";
	$x["description"] 	= "The \"Simple-backend\" module for the \"Fast PHP Page\" CMS revolutionizes website management by facilitating per-site deployment alongside other modules. This dynamic integration grants administrators a comprehensive interface for controlling various aspects such as debugging, user management, and beyond. With its foundation built on the Windmill template, users can expect an intuitive and efficient experience. The module's minimalist design ensures ease of use while offering extensive functionality, empowering users to effectively manage their websites with unparalleled simplicity and convenience. Ready to be reused, copied and what you wanna do with it! You can also find documentations at https://bugfishtm.github.io!";
	$x["short"] 		= "\"Simple-backend\" module for \"Fast PHP Page\" CMS allows per-site deployment, offering a minimalistic interface for debugging, user management, etc. Built on Windmill template for simplicity.";