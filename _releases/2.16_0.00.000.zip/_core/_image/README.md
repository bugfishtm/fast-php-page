# Default Images

**DO NOT MODIFY FILES WITHIN THIS FOLDER, AS THEY MAY BE OVERWRITTEN DURING CORE UPDATES!**

This folder contains files used by different default CMS Functionalitites and more. You can use them if you want.

Happy Imaging!  
Bugfish <3