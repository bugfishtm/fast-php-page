📁 **Images Folder**

This folder contains files used by different default CMS Functionalitites and more. You can use them if you want.

**Note:** Changes in this folder are NOT persistent and will be overwritten by core updates.

Happy coding and have a great one!  
🐟 Bugfish <3