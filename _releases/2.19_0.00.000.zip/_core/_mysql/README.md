📁 **Core Mysql Table Folder**

This folder does contain MySQL Files to be auto installed by the CMS Runtime. Do not change code here or upload your own mysql databases. Do that in your site module!

**Note:** Changes in this folder are NOT persistent and will be overwritten by core updates.

Happy coding and have a great one!  
🐟 Bugfish <3