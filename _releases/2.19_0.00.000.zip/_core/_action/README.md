📁 **Actions for Core Functionalities Folder**

This folder contains actions for the website runtime and different user operations!

**Note:** Changes in this folder are NOT persistent and will be overwritten by core updates.

Happy coding and have a great one!  
🐟 Bugfish <3