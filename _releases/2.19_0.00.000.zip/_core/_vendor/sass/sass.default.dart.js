var library = require('./sass.dart.js');
library.load({});

module.exports = library;
