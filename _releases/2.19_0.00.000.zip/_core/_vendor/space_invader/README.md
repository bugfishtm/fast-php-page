# Space Invaders implementation in HTML5 and Javascript

Hosted on:
<a href="http://oz.elentok.com/space">http://oz.elentok.com/space</a>

## Instructions

### Movement:
* Right/Left arrow keys (keyboard)
* Sliding the ship (touch screen)

### Shooting:
* Up arrow key (keyboard)
* Tapping on the screen (touch screen)
