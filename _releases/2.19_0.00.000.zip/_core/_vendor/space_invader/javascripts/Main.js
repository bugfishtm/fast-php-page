$(window).load(function () {
	var game = new SI.Game();
	game.start();
});
