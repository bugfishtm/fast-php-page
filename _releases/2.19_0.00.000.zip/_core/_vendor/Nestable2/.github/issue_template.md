### Expected behavior


### Actual behavior


### Steps to reproduce the behavior

Fork [this template](https://jsfiddle.net/s5yt9mc4/3/) to reproduce issue.
